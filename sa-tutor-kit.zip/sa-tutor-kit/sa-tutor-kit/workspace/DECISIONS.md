# Eishkom Stage 1 — Architectural & Model Decisions

**Date:** November 2026  
**Project:** Eishkom AI — South African CAPS Tutor Family  
**Release Cycle:** Stage 1 (`koeberg-stage-1`, `kendal-stage-1`, `kendal-flash-stage-1`, `gariep-stage-1`, `gariep-flash-stage-1`)

---

## 1. Finalized Model Lineup & Target Deployments

| Public Release Name | Internal Tier | Trainable Base Repo (Hugging Face) | GGUF Reference / Export Quant | Final File Size | Target Hardware & Deployment |
|---|---|---|---|---|---|
| **`koeberg-stage-1`** | Flagship Cloud (27B) | `unsloth/Qwen3.8-27B` | `UD-Q4_K_XL` (`unsloth/Qwen3.8-27B-GGUF`) | ~17.6 GB | **Cloud:** Google Cloud Run (Serverless NVIDIA L4 24GB, scale-to-zero)<br>**Local:** 16GB/20GB RAM PCs (CPU offload) |
| **`kendal-stage-1`** | Budget PC & Laptop (4B Q6) | `unsloth/Qwen3.5-4B` | `Q6_K` or `UD-Q6_K_XL` (`unsloth/Qwen3.5-4B-GGUF`) | ~3.53–4.15 GB | **Local:** GTX 1650 (4GB VRAM) desktops & 16GB/20GB RAM laptops (100% offline) |
| **`kendal-flash-stage-1`** | Mobile & Phone (4B Q4) | `empero-ai/Qwen3.8-4B-Distill` *(or unsloth 4B)* | `Q4_K_M` (`empero-ai/Qwen3.8-4B-Distill-GGUF`) | ~2.78–2.91 GB | **Local:** Midrange smartphones (6GB–8GB RAM) & 4GB PCs (100% offline) |
| **`gariep-stage-1`** | Budget Phone Tutor (2B Q6) | `empero-ai/Qwen3.8-2B-Distill` *(or unsloth 2B)* | `Q6_K` or `Q8_0` (`empero-ai/Qwen3.8-2B-Distill-GGUF`) | ~1.75–2.15 GB | **Local:** Budget smartphones (4GB RAM) & low-spec PCs (100% offline) |
| **`gariep-flash-stage-1`** | Budget Vision/OCR (2B LiquidAI) | `LiquidAI/LFM3-VL-2B` | `Q6_K` (`LiquidAI/LFM3-VL-2B-GGUF`) | ~1.55 GB | **Local:** Budget phones for high-speed document, diagram, and OCR reading |

---

## 2. Brand Identity & Release Naming Rules
- **Stage-Based Versioning:** We release as `stage-1`, `stage-1.1`, `stage-2` rather than arbitrary version increments.
- **Clean Branding:** Public model names **never** expose parameter counts or quantization suffixes. The public sees `koeberg-stage-1` (not `koeberg-27b-q4`), preserving an enterprise-grade, clean user experience.

---

## 3. Training & Compute Infrastructure
- **Google Cloud & Gen AI Credits:** Leveraging **\$60 in promotional Google Cloud billing credits** ($10/month rolling grants).
- **Vertex AI Colab Enterprise:** Training on **NVIDIA L4 GPUs (24GB VRAM)** using **Spot VM instances** (~$0.32/hr) to avoid browser disconnects and enable 27B model fine-tuning.
- **GPU Quota:** NVIDIA L4 GPU quota increased to 1 in `IAM & Admin > Quotas`.
- **Cloud Run Hosting (Scale-to-Zero):** For `koeberg-stage-1`, deploy containerized Ollama/vLLM on Google Cloud Run with an NVIDIA L4 GPU. Configured with `--min-instances 0` so it scales down to \$0.00/hr when idle, only drawing credit during active chat queries (~$0.015/min).

---

## 4. Base Models vs. GGUF Files
- **Rule:** Never pass a compiled `-GGUF` repository to `train_sft.py`.
- **Action:** Fine-tune unquantized Transformers base repos using Unsloth QLoRA (4-bit base weights + 16-bit LoRA adapters).
- **Multi-Quant Export:** Compile to `.gguf` at the end using `training/export_gguf.py`. Export both `kendal-stage-1` (Q6) and `kendal-flash-stage-1` (Q4) from a single 4B training run.

---

## 5. Cross-Tier Knowledge Distillation
- Train `koeberg-stage-1` (27B) first on the core South African CAPS dataset.
- Use Koeberg to solve 2,000–5,000 of the hardest DBE exam questions (Grade 11–12 Mathematics Paper 2, Physical Sciences, and Afrikaans grammar).
- Verify Koeberg's answers against the DBE memorandums and add them into `dataset.jsonl` to train Kendal (4B) and Gariep (2B).

---

## 6. Pedagogical Defaults & Policies
- **Thinking Default:** Enabled for Mathematics and Physical Sciences; disabled by default on phone profiles for fast turnaround.
- **Maths Notation:** LaTeX rendered via KaTeX in the user app.
- **Decimal Convention:** Decimal point (2.5) for internal consistency and tool communication; accepts decimal comma (2,5) from South African learners.
- **Teacher API:** DeepSeek V4.1 Flash 1017 (MIT License, legally safe for distillation) and Google Gemini Flash via Vertex AI.
