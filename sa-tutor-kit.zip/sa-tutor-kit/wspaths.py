"""wspaths.py - where things live. Every script uses p("some", "folder") instead of hard-coded paths.

The workspace folder defaults to ./workspace (next to where you run the script). To put it somewhere
else (for example on Google Drive in Colab), set the environment variable SA_WORKSPACE.
"""
import os
from pathlib import Path

KIT_ROOT = Path(__file__).resolve().parent


def root():
    return Path(os.environ.get("SA_WORKSPACE", "workspace"))


def p(*parts):
    return root().joinpath(*parts)


def ensure_parent(path):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    return Path(path)


def read_jsonl(path):
    import json
    out = []
    with open(path, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                out.append(json.loads(line))
    return out


def write_jsonl(path, rows):
    import json
    ensure_parent(path)
    with open(path, "w", encoding="utf-8") as f:
        for r in rows:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")
    return len(rows)


def append_jsonl(path, row):
    import json
    ensure_parent(path)
    with open(path, "a", encoding="utf-8") as f:
        f.write(json.dumps(row, ensure_ascii=False) + "\n")
