#!/usr/bin/env python3
"""
train_sft.py - teach base models your South African CAPS tutor behaviour (supervised fine-tuning with LoRA).
Run in Vertex AI Colab Enterprise on an NVIDIA L4 GPU (or Google Colab on T4).

EISHKOM STAGE 1 TRAINING RUNS:
    # 1. Train Koeberg Flagship Cloud (27B) - runs on L4 Spot VM (~5.5 hrs, ~$1.76):
    python training/train_sft.py --model unsloth/Qwen3.8-27B --data workspace/build/r1 --out workspace/runs/r1-koeberg --load-4bit --epochs 3

    # 2. Train Kendal Desktop & Flash Mobile (4B) - runs on L4 Spot VM (~1.0 hr, ~$0.32):
    python training/train_sft.py --model unsloth/Qwen3.5-4B --data workspace/build/r1 --out workspace/runs/r1-kendal --load-4bit --epochs 3
    # Or train the mobile distill branch directly:
    # python training/train_sft.py --model empero-ai/Qwen3.8-4B-Distill --data workspace/build/r1 --out workspace/runs/r1-kendal-flash --load-4bit

    # 3. Train Gariep Budget Phone Tutor (2B) - runs on L4 Spot VM (~35 mins, ~$0.19):
    python training/train_sft.py --model empero-ai/Qwen3.8-2B-Distill --data workspace/build/r1 --out workspace/runs/r1-gariep --load-4bit --epochs 3

    # Smoke checks:
    # Dry-run check on any PC (no GPU): render tokens and inspect loss mask:
    python training/train_sft.py --model unsloth/Qwen3.5-4B --data workspace/build/r1 --dry-run
    # The "can it memorise?" 20-sample test (loss should fall close to 0):
    python training/train_sft.py --model unsloth/Qwen3.5-4B --data workspace/build/r1 --out workspace/runs/overfit --limit 20 --epochs 15

CRITICAL TRAINING RULE: BASE REPOS ONLY (NEVER PASS -GGUF)
  * Pass only unquantized base Hugging Face models (e.g. unsloth/Qwen3.8-27B, unsloth/Qwen3.5-4B).
  * GGUF repositories are compiled read-only inference files; passing a GGUF repo to train_sft.py will crash.
  * Export to GGUF (UD-Q4_K_XL, Q6_K, Q4_K_M) happens AFTER training completes via training/export_gguf.py.
"""
import argparse
import hashlib
import inspect
import json
import math
import os
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

USE_UNSLOTH = False
if "--no-unsloth" not in sys.argv and "--dry-run" not in sys.argv:
    try:
        import unsloth  # noqa: F401  (Unsloth must be imported BEFORE transformers/peft so it can patch them)
        USE_UNSLOTH = True
    except Exception as e:                                                    # noqa: BLE001
        print(f"(Unsloth not available: {type(e).__name__}; using plain transformers + peft, slower and hungrier)")

import tutor_data as td  # noqa: E402
from render import load_tokenizer, render_file, show  # noqa: E402
from wspaths import read_jsonl  # noqa: E402

DEFAULT_TARGETS = ["q_proj", "k_proj", "v_proj", "o_proj", "gate_proj", "up_proj", "down_proj"]


class Rows:
    def __init__(self, rows):
        self.rows = rows

    def __len__(self):
        return len(self.rows)

    def __getitem__(self, i):
        return self.rows[i]


def make_collator(pad_id):
    import torch

    def collate(batch):
        m = max(len(b["input_ids"]) for b in batch)
        ids = torch.full((len(batch), m), pad_id, dtype=torch.long)
        lab = torch.full((len(batch), m), -100, dtype=torch.long)
        att = torch.zeros((len(batch), m), dtype=torch.long)
        for i, b in enumerate(batch):
            n = len(b["input_ids"])
            ids[i, :n] = torch.tensor(b["input_ids"])
            lab[i, :n] = torch.tensor(b["labels"])
            att[i, :n] = 1
        return {"input_ids": ids, "attention_mask": att, "labels": lab}
    return collate


def load_model(a):
    targets = a.target_modules.split(",") if a.target_modules else DEFAULT_TARGETS
    if USE_UNSLOTH:
        from unsloth import FastLanguageModel
        kw = dict(model_name=a.model, max_seq_length=a.max_len, load_in_4bit=a.load_4bit)
        try:
            model, tok = FastLanguageModel.from_pretrained(**kw, load_in_16bit=not a.load_4bit)
        except TypeError:
            model, tok = FastLanguageModel.from_pretrained(**kw)
        model = FastLanguageModel.get_peft_model(model, r=a.rank, lora_alpha=a.alpha, lora_dropout=0.0, bias="none",
                                                 target_modules=targets, use_gradient_checkpointing="unsloth", random_state=a.seed)
    else:
        import torch
        from peft import LoraConfig, get_peft_model
        from transformers import AutoModelForCausalLM

        is_tpu = False
        try:
            import torch_xla.core.xla_model as xm
            is_tpu = True
        except Exception:
            if "TPU_NAME" in os.environ or "PJRT_DEVICE" in os.environ:
                is_tpu = True

        if is_tpu:
            dtype = torch.bfloat16
            print("[TPU Optimizer] Detected Cloud TPU environment. Using native bfloat16 without device_map.")
            model = AutoModelForCausalLM.from_pretrained(a.model, torch_dtype=dtype)
        else:
            dtype = torch.bfloat16 if torch.cuda.is_available() and torch.cuda.is_bf16_supported() else torch.float16
            model = AutoModelForCausalLM.from_pretrained(a.model, torch_dtype=dtype, device_map="auto")

        model.gradient_checkpointing_enable()
        model.enable_input_require_grads()
        model = get_peft_model(model, LoraConfig(r=a.rank, lora_alpha=a.alpha, lora_dropout=0.0, bias="none",
                                                 target_modules=targets, task_type="CAUSAL_LM"))
        tok = None
    tok = getattr(tok, "tokenizer", tok)
    trainable = sum(p.numel() for p in model.parameters() if p.requires_grad)
    total = sum(p.numel() for p in model.parameters())
    print(f"trainable parameters: {trainable:,} of {total:,} ({100 * trainable / total:.2f}%)")
    if trainable / total < 0.001:
        print("WARNING: very few trainable parameters. The target module names probably do not match this architecture. "
              "Copy target_modules from Unsloth's notebook for your model and pass them with --target-modules a,b,c")
    return model, tok


def sanity_generate(model, tok_render, a):
    """After training: one quick answer, so you SEE whether the format came out right (not a test, a smoke check)."""
    import torch
    if USE_UNSLOTH:
        from unsloth import FastLanguageModel
        FastLanguageModel.for_inference(model)
    control = {"subject": "mathematics", "grade": 9, "subject_language": "en", "response_language": "en", "strategy": "step_walkthrough",
               "answer_policy": "guided", "student_level": "on_track", "tone": "friendly_playful", "response_length": "short",
               "math_format": "latex", "tools": []}
    msgs = [{"role": "system", "content": td.render_system(control, set(td.OPTIONAL_RENDER))},
            {"role": "user", "content": "Solve for x: 5x + 7 = 32"}]
    kw = {"enable_thinking": False} if a.think_style == "qwen" else {}
    text = tok_render.apply_chat_template(msgs, tokenize=False, add_generation_prompt=True, **kw)
    inputs = tok_render(text, return_tensors="pt", add_special_tokens=False).to(model.device)
    with torch.no_grad():
        out = model.generate(**inputs, max_new_tokens=200, do_sample=False)
    print("\n--- sanity answer (thinking off) ---\n" + tok_render.decode(out[0][inputs["input_ids"].shape[1]:], skip_special_tokens=True))


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--model", required=True, help="e.g. unsloth/Qwen3.5-4B (the SAME model you will export and serve)")
    ap.add_argument("--tokenizer", help="default: same as --model")
    ap.add_argument("--data", required=True, help="a build/<name> folder with train.jsonl (and val.jsonl)")
    ap.add_argument("--out", help="run folder (put it on Google Drive in Colab)")
    ap.add_argument("--think-style", choices=["qwen", "gemma", "none"], default="qwen")
    ap.add_argument("--max-len", type=int, default=4096)
    ap.add_argument("--epochs", type=float, default=2.0, help="passes over the data. 2-3 is usual; more memorises")
    ap.add_argument("--lr", type=float, default=2e-4, help="learning rate for LoRA (1e-4 to 3e-4 is normal)")
    ap.add_argument("--rank", type=int, default=16, help="LoRA size: 16 is a good start, 32-64 if you add many skills")
    ap.add_argument("--alpha", type=int, default=16)
    ap.add_argument("--batch", "--batch-size", dest="batch", type=int, default=0, help="batch size per device. 0 = auto-scale based on VRAM/model size")
    ap.add_argument("--grad-accum", "--grad-accum-steps", "--gradient-accumulation-steps", dest="grad_accum", type=int, default=0, help="effective batch = batch x grad-accum. 0 = auto-scale")
    ap.add_argument("--seed", type=int, default=3407)
    ap.add_argument("--limit", type=int, default=0, help="use only the first N samples (overfit test)")
    ap.add_argument("--target-modules", help="comma list; default q,k,v,o,gate,up,down projections")
    ap.add_argument("--load-4bit", action="store_true")
    ap.add_argument("--no-unsloth", action="store_true")
    ap.add_argument("--dry-run", action="store_true", help="render + statistics only; needs no GPU")
    ap.add_argument("--resume", action="store_true")
    ap.add_argument("--show", type=int, default=1, help="print N rendered samples")
    a = ap.parse_args()

    # Proactive auto-correction for model name, template variables, and GGUF suffixes
    if a.model:
        if "{MODEL}" in a.model:
            a.model = "unsloth/Qwen3.5-4B"
            print(f"[AUTO-FIX] Detected raw variable in --model. Defaulting to: '{a.model}'")
        if a.model.endswith("-GGUF") or a.model.endswith(".gguf") or "-GGUF" in a.model or "-gguf" in a.model:
            clean_model = a.model.replace("-GGUF", "").replace("-gguf", "").replace(".gguf", "")
            print(f"\n[AUTO-CORRECTION] Detected GGUF suffix in base model name: '{a.model}'")
            print("GGUF files are compiled, read-only inference files and cannot be fine-tuned.")
            print(f"Auto-switching to base Hugging Face repository: '{clean_model}'\n")
            a.model = clean_model

    if a.data:
        if "{ROUND}" in a.data:
            a.data = a.data.replace("{ROUND}", "r1")
            print(f"[AUTO-FIX] Detected raw variable in --data. Resolved to: '{a.data}'")
        data_p = Path(a.data)
        if not data_p.exists():
            for cand in [Path("workspace/build/r1"), Path("build/r1")]:
                if cand.exists():
                    print(f"[AUTO-FIX] Data folder '{a.data}' not found. Auto-resolved to: '{cand}'")
                    a.data = str(cand)
                    break

    if a.out:
        if "{ROUND}" in a.out:
            a.out = a.out.replace("{ROUND}", "r1")
            print(f"[AUTO-FIX] Detected raw variable in --out. Resolved to: '{a.out}'")

    # Dynamic VRAM/HBM optimization: Auto-scale batch size based on GPU/TPU capacity and model tier
    if a.batch == 0 or a.grad_accum == 0:
        gpu_mem_gb = 24.0
        gpu_name = "GPU"
        is_tpu = False
        try:
            import torch_xla.core.xla_model as xm
            is_tpu = True
            gpu_name = "Cloud TPU v5e-1"
            gpu_mem_gb = 16.0
        except Exception:
            if "TPU_NAME" in os.environ or "PJRT_DEVICE" in os.environ:
                is_tpu = True
                gpu_name = "Cloud TPU v5e-1"
                gpu_mem_gb = 16.0

        if not is_tpu:
            try:
                import torch
                if torch.cuda.is_available():
                    gpu_mem_gb = torch.cuda.get_device_properties(0).total_memory / (1024**3)
                    gpu_name = torch.cuda.get_device_name(0)
            except Exception:
                pass

        m_lower = a.model.lower()
        is_small = any(k in m_lower for k in ["0.5b", "1b", "1.5b", "2b"])
        is_mid = any(k in m_lower for k in ["3b", "4b", "7b", "8b"])

        if gpu_mem_gb >= 20.0:  # e.g. NVIDIA L4 (24GB VRAM) or A100
            if "1b" in m_lower or "0.5b" in m_lower:
                # Ultra-light model (Baby Jake class): Saturate VRAM for ultra-fast training (~10 mins)
                a.batch = 16 if a.batch == 0 else a.batch
                a.grad_accum = 1 if a.grad_accum == 0 else a.grad_accum
                target = "~14-16GB VRAM (Ultra-Fast ~10 min)"
            elif is_small:  # 2B (Gariep class): High VRAM allocation as requested (~15-20 mins)
                a.batch = 8 if a.batch == 0 else a.batch
                a.grad_accum = 2 if a.grad_accum == 0 else a.grad_accum
                target = "~16-18GB VRAM (High Throughput ~15-20 min)"
            elif is_mid:  # 4B (Kendal class): Balanced VRAM (~18GB) (~45-55 mins)
                a.batch = 4 if a.batch == 0 else a.batch
                a.grad_accum = 4 if a.grad_accum == 0 else a.grad_accum
                target = "~17-19GB VRAM (Optimal 4B ~45-55 min)"
            else:  # 14B / 27B / 32B (Koeberg class): Safe headroom to prevent any OOM
                a.batch = 2 if a.batch == 0 else a.batch
                a.grad_accum = 8 if a.grad_accum == 0 else a.grad_accum
                target = "~20-21GB VRAM (Safe headroom, 0% OOM risk)"
        else:  # Smaller GPU (e.g. Tesla T4 15-16GB VRAM)
            if is_small:
                # 2B model on T4: saturate 15GB VRAM with batch=8, grad_accum=2 for max speed (~20-25 mins)
                a.batch = 8 if a.batch == 0 else a.batch
                a.grad_accum = 2 if a.grad_accum == 0 else a.grad_accum
                target = "~10-12GB VRAM (Aggressive T4 throughput for 2B)"
            elif is_mid:
                a.batch = 2 if a.batch == 0 else a.batch
                a.grad_accum = 8 if a.grad_accum == 0 else a.grad_accum
                target = "~12-14GB VRAM (T4 safe for 4B)"
            else:
                a.batch = 1 if a.batch == 0 else a.batch
                a.grad_accum = 16 if a.grad_accum == 0 else a.grad_accum
                target = "~14GB VRAM (Warning: 27B strongly recommended on L4)"

        print(f"[VRAM Optimizer] Detected {gpu_name} ({gpu_mem_gb:.1f} GB VRAM). "
              f"Auto-configured batch={a.batch}, grad_accum={a.grad_accum} for {a.model} ({target}).")

    data = Path(a.data)
    tok_r = load_tokenizer(a.tokenizer or a.model)
    train_rows, st = render_file(data / "train.jsonl", tok_r, a.think_style, a.max_len, a.limit)
    val_rows, vst = (render_file(data / "val.jsonl", tok_r, a.think_style, a.max_len)
                     if (data / "val.jsonl").exists() and (data / "val.jsonl").stat().st_size else ([], {}))
    for s in read_jsonl(data / "train.jsonl")[: a.show]:
        show(s, tok_r, a.think_style)
    print("\ntrain:", json.dumps(st))
    print("val  :", json.dumps(vst))
    if st["mismatch"]:
        sys.exit("TEMPLATE PROBLEM (see first_error above). Fix before training.")
    if not train_rows:
        sys.exit("no training samples after rendering.")
    steps_per_epoch = math.ceil(len(train_rows) / (a.batch * a.grad_accum))
    total_steps = max(1, int(steps_per_epoch * a.epochs))
    print(f"\n{len(train_rows)} samples, {steps_per_epoch} optimizer steps per epoch, {total_steps} steps in total, "
          f"{st['trainable_tokens']:,} tokens to learn from per epoch")
    if a.dry_run:
        print("dry run finished: nothing was trained.")
        return
    if not a.out:
        sys.exit("--out is required for a real run")

    import torch
    from transformers import Trainer, TrainingArguments, TrainerCallback

    class CleanProgressCallback(TrainerCallback):
        def __init__(self, total_steps):
            self.total_steps = total_steps
            self.t0 = time.time()
        def on_log(self, args, state, control, logs=None, **kwargs):
            if not logs: return
            step = state.global_step
            loss = logs.get("loss")
            eval_loss = logs.get("eval_loss")
            lr = logs.get("learning_rate", 0)
            elapsed = (time.time() - self.t0) / 60
            pct = 100 * step / max(1, self.total_steps)

            vram_str = ""
            if torch.cuda.is_available():
                res_gb = torch.cuda.memory_reserved() / (1024**3)
                vram_str = f" | VRAM: {res_gb:.1f}GB"

            if eval_loss is not None:
                print(f"  ===> [Epoch {state.epoch:.1f} Validation] Eval Loss: {eval_loss:.4f}{vram_str}", flush=True)
            if loss is not None:
                loss_str = f"{loss:.4f}" if isinstance(loss, float) else str(loss)
                print(f"  -> [Step {step:3d}/{self.total_steps} ({pct:4.1f}%)] Loss: {loss_str} | LR: {lr:.2e} | Elapsed: {elapsed:4.1f}m{vram_str}", flush=True)

    model, tok_model = load_model(a)
    pad_id = (tok_model or tok_r).pad_token_id if (tok_model or tok_r).pad_token_id is not None else tok_r.eos_token_id
    is_tpu = False
    try:
        import torch_xla.core.xla_model as xm
        is_tpu = True
    except Exception:
        if "TPU_NAME" in os.environ or "PJRT_DEVICE" in os.environ:
            is_tpu = True

    if is_tpu:
        bf16 = True
        fp16 = False
        optim = "adamw_torch"
        print("[TPU Training] Initializing Hugging Face Trainer with PyTorch/XLA and bfloat16.")
    else:
        bf16 = torch.cuda.is_available() and torch.cuda.is_bf16_supported()
        fp16 = not bf16
        try:
            import bitsandbytes  # noqa: F401
            optim = "adamw_8bit"
        except ImportError:
            optim = "adamw_torch"
    sig = inspect.signature(TrainingArguments.__init__).parameters
    out = Path(a.out)
    kw = dict(output_dir=str(out / "checkpoints"), per_device_train_batch_size=a.batch, gradient_accumulation_steps=a.grad_accum,
              num_train_epochs=a.epochs, learning_rate=a.lr, lr_scheduler_type="cosine", warmup_steps=max(1, int(0.03 * total_steps)),
              weight_decay=0.01, logging_steps=25, disable_tqdm=True, save_strategy="epoch", save_total_limit=2, seed=a.seed, report_to="none",
              remove_unused_columns=False, optim=optim, bf16=bf16, fp16=not bf16, dataloader_num_workers=0)
    if val_rows:
        kw["eval_strategy" if "eval_strategy" in sig else "evaluation_strategy"] = "epoch"
        kw["per_device_eval_batch_size"] = a.batch
    clean_cb = CleanProgressCallback(total_steps)
    trainer = Trainer(model=model, args=TrainingArguments(**kw), train_dataset=Rows(train_rows),
                      eval_dataset=Rows(val_rows) if val_rows else None, data_collator=make_collator(pad_id), callbacks=[clean_cb])
    t0 = time.time()
    result = trainer.train(resume_from_checkpoint=True if a.resume else None)
    minutes = (time.time() - t0) / 60

    # Memory cleanup before saving
    import gc
    gc.collect()
    if torch.cuda.is_available():
        torch.cuda.empty_cache()

    adapter = out / "adapter"
    model.save_pretrained(str(adapter))
    (tok_model or tok_r).save_pretrained(str(adapter))
    (out / "log_history.json").write_text(json.dumps(trainer.state.log_history, indent=1), encoding="utf-8")
    sha = hashlib.sha1((data / "train.jsonl").read_bytes()).hexdigest()
    (out / "run.json").write_text(json.dumps({
        "model": a.model, "data": str(data), "train_jsonl_sha1": sha, "args": vars(a), "train_stats": st, "val_stats": vst,
        "final_train_loss": result.training_loss, "minutes": round(minutes, 1), "unsloth": USE_UNSLOTH,
        "when": time.strftime("%Y-%m-%d %H:%M"), "kit_render_version": td.RENDER_VERSION}, indent=2, default=str), encoding="utf-8")
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        logs = [x for x in trainer.state.log_history if "loss" in x]
        evals = [x for x in trainer.state.log_history if "eval_loss" in x]
        plt.figure(figsize=(6, 3.5))
        plt.plot([x["step"] for x in logs], [x["loss"] for x in logs], label="train loss")
        if evals:
            plt.plot([x["step"] for x in evals], [x["eval_loss"] for x in evals], "o-", label="val loss")
        plt.xlabel("step"); plt.ylabel("loss"); plt.legend(); plt.tight_layout(); plt.savefig(out / "loss.png", dpi=120)
    except Exception:                                                         # noqa: BLE001
        pass
    print(f"\n[Training Complete] Saved adapter to {adapter} ({minutes:.1f} minutes, final train loss {result.training_loss:.3f})")
    print("READ loss.png: train loss should fall and flatten; val loss falling then RISING means over-fitting.")
    try:
        sanity_generate(model, tok_r, a)
    except Exception as e:                                                    # noqa: BLE001
        print(f"(sanity generation skipped: {type(e).__name__}: {e})")
    print("\nNEXT STEPS:")
    print("  1. Evaluate the model:  Run Notebook Cell 7 (or Cell 8 for consistency n=5)")
    print("  2. Export GGUF files:   Run Notebook Cell 9 (exports clean Stage 1 quant files in minutes)")


if __name__ == "__main__":
    main()
